import styled from "@emotion/styled";

const MoyaKeywordArea = () => {
  return <Wrap></Wrap>;
};

export default MoyaKeywordArea;

const Wrap = styled.section``;
