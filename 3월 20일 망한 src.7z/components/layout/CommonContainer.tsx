import styled from "@emotion/styled";

const CommonContainer = styled.div`
  width: 1240px;
  margin: 0 auto;
`;

export default CommonContainer;
