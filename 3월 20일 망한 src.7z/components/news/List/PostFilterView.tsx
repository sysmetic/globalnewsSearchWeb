import styled from "@emotion/styled";
import React, { useEffect } from "react";
import TextArticleList from "./TextArticleList";
import ImageArticleList from "./ImageArticleList";
import { useNewsFormats } from "../hooks/useNewsFormat";
import { useParams } from "react-router-dom";
import { useInView } from "react-intersection-observer";
import { useAppSelector } from "../../../redux/hooks";
import CommonContainer from "./../../layout/CommonContainer";
import { useSearch } from "./../../../hooks/useSearch";
const PostFilterView = () => {
  const { NewsFormats } = useNewsFormats();
  const newListData = useAppSelector(state => state.newsList.newListData);
  useEffect(() => {}, []);
  const { searchNews } = useSearch();
  const { identifier } = useParams();
  useEffect(() => {
    searchNews("Sector", identifier);

  }, [identifier, searchNews]);
  console.log(NewsFormats, "포맷", newListData, "뉴스리스트 데이터");
  return (
    <CommonContainer>
      {(function test() {
        switch (true) {
          case NewsFormats === "Image":
            return (
              <ImageContent>
                <ImageArticleList newListData={newListData} />
              </ImageContent>
            );
          case NewsFormats === "Text":
            return (
              <TextContent>
                <TextArticleList newListData={newListData} />;
              </TextContent>
            );
          default:
            return null;
        }
      })()}
    </CommonContainer>
  );
};

export default PostFilterView;

const ImageContent = styled.div`
  column-count: 3;
  column-gap: 20px;
  padding-bottom: 280px;
  padding-top: 50px;
`;
const TextContent = styled.div`
  width: 100%;
  padding-bottom: 280px;
`;
//데이터를 [0]번째 인덱스만 출력하게해라
const ObserverView = styled.div`
  height: 50px;
`;
