import styled from "@emotion/styled";
import React from "react";
import MainContainer from "./main/MainContainer";
import TabListContainer from "./tabs/TabListContainer";
const TabRender = () => {
  return <TabView></TabView>;
};

export default TabRender;

const TabView = styled.div``;
