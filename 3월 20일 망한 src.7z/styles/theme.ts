export const theme = {
  primaryColor: "#144056",
  BlueGreenColor: "#48C0B7"
};

// export const h1 = {
//   size:"22px",
//   family:"700"
// }

// export const h2 = {
//   size:"22px",
//   family:"600"
// }

// export const h3 = {
//   size:"20px",
//   family:"600"
// }
// export const subtitle1 = {
//   size:"16px",
//   family:"700"
// }
// export const subtitle2 = {
//   size:"16px",
//   family:"700"
// }

// export const body1 = {
//   size:"16px",
//   family:"500"
// }
// export const body2 = {
//   size:"16px",
//   family:"400"
// }

// export const body3 = {
//   size:"16px",
//   family:"300"
// }

// export const body4 = {
//   size:"14px",
//   family:"400"
// }

// export const button1 = {
//   size:"24px",
//   family:"500"
// }
// export const button2 = {
//   size:"16px",
//   family:"400"
// }

// export const caption = {
//   size:"14px",
//   family:"300"
// }

// export const overline = {
//   size:"18px",
//   family:"500"
// }