
declare module 'useInfiniteScroll' { // 이 부분 'example-lib'과
  const useInfiniteScroll: boolean;
  export default useInfiniteScroll;
}