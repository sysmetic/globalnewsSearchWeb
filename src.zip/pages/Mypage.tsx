import MyPage from "../components/myPage/Mypage"

const Mypage = () => {
  return <MyPage />;
}

export default Mypage;